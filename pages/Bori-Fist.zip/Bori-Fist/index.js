const fs = require('fs');
const readline = require('readline');
const { spawn } = require('child_process');
const { 
  Connection, 
  Keypair, 
  PublicKey, 
  Transaction, 
  SystemProgram, 
  LAMPORTS_PER_SOL, 
  clusterApiUrl 
} = require('@solana/web3.js');

// Configuración Global y Constantes
const WALLET_FILE = 'wallet.json';
const HOLDERS_FILE = 'holders.json';
const BRCN_TOKEN_MINT = 'DNjxZHEuf6iTSDvic4PDi7oE6UJzmxL616axKfhzw1mD';
const PYTHON_SCRIPT = 'price_checker.py';

// Conexión Unificada a Solana MAINNET-BETA
const connection = new Connection(clusterApiUrl('mainnet-beta'), 'confirmed');

// Interfaz de lectura
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Utilidad para pausar la pantalla y esperar que el usuario presione ENTER
function askToContinue(callback) {
  rl.question('\nPresiona ENTER para volver al menú principal...', () => {
    callback();
  });
}

// ==========================================
// MÓDULOS DE UTILIDAD
// ==========================================

function loadOrCreateWallet() {
  if (fs.existsSync(WALLET_FILE)) {
    const secretKeyArray = JSON.parse(fs.readFileSync(WALLET_FILE, 'utf8'));
    return Keypair.fromSecretKey(Uint8Array.from(secretKeyArray));
  } else {
    const newWallet = Keypair.generate();
    const secretKeyArray = Array.from(newWallet.secretKey);
    fs.writeFileSync(WALLET_FILE, JSON.stringify(secretKeyArray, null, 2));
    console.log('✨ Nueva billetera generada y guardada en wallet.json');
    return newWallet;
  }
}

function loadHolders() {
  if (fs.existsSync(HOLDERS_FILE)) {
    try {
      return JSON.parse(fs.readFileSync(HOLDERS_FILE, 'utf8'));
    } catch (e) {
      return [];
    }
  }
  return [];
}

function saveHolders(data) {
  fs.writeFileSync(HOLDERS_FILE, JSON.stringify(data, null, 2));
}

async function getBRCNBalance(walletAddress) {
  try {
    const walletPubKey = new PublicKey(walletAddress);
    const mintPubKey = new PublicKey(BRCN_TOKEN_MINT);
    const response = await connection.getParsedTokenAccountsByOwner(walletPubKey, { mint: mintPubKey });

    if (response.value.length === 0) return 0;
    return response.value[0].account.data.parsed.info.tokenAmount.uiAmount || 0;
  } catch (error) {
    return 'Error/Inválida';
  }
}

// ==========================================
// FUNCIONES PRINCIPALES
// ==========================================

// 1. Ejecutar BORISCAN-PRO (Herramienta Python Integrada)
function runPythonAnalyzer() {
  console.clear();
  if (!fs.existsSync(PYTHON_SCRIPT)) {
    console.log(`❌ No se encontró el archivo '${PYTHON_SCRIPT}' en el directorio actual.`);
    console.log(`Asegúrate de guardar el script de Python con ese nombre.`);
    return askToContinue(mainMenu);
  }

  console.log('🚀 Iniciando BORISCAN-PRO (Python Analyzer)...');
  console.log('💡 Presiona Ctrl+C para detener el análisis y regresar al menú.\n');

  // Determinar comando ejecutable de python (python3 o python)
  const pythonCmd = process.platform === 'win32' ? 'python' : 'python3';
  
  const pyProcess = spawn(pythonCmd, [PYTHON_SCRIPT], {
    stdio: 'inherit',
    env: process.env
  });

  pyProcess.on('error', (err) => {
    console.error(`\n❌ Error al intentar ejecutar Python: ${err.message}`);
    askToContinue(mainMenu);
  });

  pyProcess.on('close', (code) => {
    console.log(`\n🛑 Analizador finalizado.`);
    askToContinue(mainMenu);
  });
}

// 2. Transferir SOL (Mainnet-Beta)
async function sendSolMainnet() {
  console.clear();
  console.log('===================================================');
  console.log('      🚨 ENVIAR SOL EN SOLANA (MAINNET-BETA)       ');
  console.log('===================================================');
  console.log('⚠️  ATENCIÓN: Transacción en RED REAL. Los fondos son reales.');
  console.log('===================================================\n');

  if (!fs.existsSync(WALLET_FILE)) {
    console.log('❌ No se encontró wallet.json. Usa la Opción 5 para generarla.');
    return askToContinue(mainMenu);
  }

  const secretKeyArray = JSON.parse(fs.readFileSync(WALLET_FILE, 'utf8'));
  const senderKeypair = Keypair.fromSecretKey(Uint8Array.from(secretKeyArray));

  console.log('📍 Wallet de Origen:', senderKeypair.publicKey.toBase58());

  try {
    const balance = await connection.getBalance(senderKeypair.publicKey);
    const balanceInSol = balance / LAMPORTS_PER_SOL;
    console.log(`💰 Saldo real disponible: ${balanceInSol} SOL\n`);

    if (balanceInSol === 0) {
      console.log('⚠️ No tienes suficientes fondos reales para realizar una transferencia.');
      return askToContinue(mainMenu);
    }

    rl.question('📬 Dirección pública de DESTINO: ', (destAddress) => {
      rl.question('💸 Cantidad de SOL a enviar: ', (amountStr) => {
        const amountSol = parseFloat(amountStr);

        if (isNaN(amountSol) || amountSol <= 0 || amountSol > balanceInSol) {
          console.log('❌ Cantidad inválida o saldo insuficiente.');
          return askToContinue(mainMenu);
        }

        rl.question(`\n⚠️  ¿Confirmas el envío de ${amountSol} SOL a ${destAddress}? (s/n): `, async (confirm) => {
          if (confirm.toLowerCase() !== 's') {
            console.log('❌ Transacción cancelada por el usuario.');
            return askToContinue(mainMenu);
          }

          try {
            const toPublicKey = new PublicKey(destAddress);
            console.log('\n⏳ Creando y firmando transacción en Mainnet...');

            const transaction = new Transaction().add(
              SystemProgram.transfer({
                fromPubkey: senderKeypair.publicKey,
                toPubkey: toPublicKey,
                lamports: Math.floor(amountSol * LAMPORTS_PER_SOL),
              })
            );

            const signature = await connection.sendTransaction(transaction, [senderKeypair]);
            console.log('✅ ¡Transacción confirmada en Mainnet!');
            console.log('🔗 Firma (TxID):', signature);
            console.log(`🔍 Verificar en Solana Explorer: https://explorer.solana.com/tx/${signature}`);
          } catch (error) {
            console.error('❌ Error al procesar la transacción:', error.message);
          }
          askToContinue(mainMenu);
        });
      });
    });
  } catch (error) {
    console.error('❌ Error de conexión a Mainnet:', error.message);
    askToContinue(mainMenu);
  }
}

// 3. Consultar saldo SOL de cualquier cartera
function checkAnyBalance() {
  console.clear();
  console.log('====================================');
  console.log('🔍 CONSULTAR SALDO DE CUALQUIER WALLET (MAINNET)');
  console.log('====================================\n');

  rl.question('📍 Introduce la dirección de Solana: ', async (walletAddress) => {
    try {
      const publicKey = new PublicKey(walletAddress.trim());
      const balance = await connection.getBalance(publicKey);
      console.log(`\n💰 Saldo: ${balance / LAMPORTS_PER_SOL} SOL`);
    } catch (error) {
      console.log('\n❌ Dirección pública no válida.');
    }
    askToContinue(mainMenu);
  });
}

// 4. Ver claves de la billetera local
function exportKeys() {
  console.clear();
  if (!fs.existsSync(WALLET_FILE)) {
    console.log('❌ No se encontró el archivo wallet.json.');
  } else {
    const secretKeyArray = JSON.parse(fs.readFileSync(WALLET_FILE, 'utf8'));
    const wallet = Keypair.fromSecretKey(Uint8Array.from(secretKeyArray));

    console.log('====================================');
    console.log('🔑 DETALLES DE LA BILLETERA LOCAL');
    console.log('====================================');
    console.log('📍 Dirección pública:', wallet.publicKey.toBase58());
    console.log('------------------------------------');
    console.log('🔑 Clave Secreta en formato Array:');
    console.log(JSON.stringify(secretKeyArray));
    console.log('====================================');
  }
  askToContinue(mainMenu);
}

// 5. Cargar / Generar billetera local y ver saldo en Mainnet
async function showLocalWallet() {
  console.clear();
  console.log('====================================');
  console.log('📂 ESTADO DE BILLETERA LOCAL (MAINNET)');
  console.log('====================================\n');

  const wallet = loadOrCreateWallet();
  console.log('📍 Dirección Pública:', wallet.publicKey.toBase58());

  try {
    const balance = await connection.getBalance(wallet.publicKey);
    console.log(`💰 Saldo en Mainnet: ${balance / LAMPORTS_PER_SOL} SOL`);
  } catch (error) {
    console.error('❌ Error al obtener el saldo:', error.message);
  }

  askToContinue(mainMenu);
}

// 6. Gestor de Holders
async function holderManager() {
  console.clear();
  const holders = loadHolders();

  console.log('===========================================================');
  console.log('      🏷️  GESTOR Y ETIQUETADOR DE HOLDERS (BRCN / MAINNET)');
  console.log('===========================================================\n');

  if (holders.length === 0) {
    console.log('  ⚠️  No hay carteras registradas.\n');
  } else {
    console.log('  📋 CARTERAS REGISTRADAS:\n');
    for (let i = 0; i < holders.length; i++) {
      const h = holders[i];
      const balance = await getBRCNBalance(h.address);
      console.log(`  ${i + 1}. [${h.label}]`);
      console.log(`     📍 Dirección: ${h.address}`);
      console.log(`     💰 Balance BRCN: ${balance}\n`);
    }
  }

  console.log('-----------------------------------------------------------');
  console.log('  1. Registrar / Etiquetar nueva cartera');
  console.log('  2. Editar etiqueta de una cartera');
  console.log('  3. Eliminar una cartera');
  console.log('  4. Volver al menú principal');
  console.log('-----------------------------------------------------------');

  rl.question('👉 Selecciona una opción: ', (opt) => {
    switch (opt.trim()) {
      case '1':
        rl.question('\n📝 Etiqueta: ', (label) => {
          rl.question('📍 Dirección Pública: ', (address) => {
            try {
              new PublicKey(address);
              const currentHolders = loadHolders();
              currentHolders.push({ label: label || 'Sin Etiqueta', address });
              saveHolders(currentHolders);
              console.log('✅ Registrada con éxito.');
            } catch (e) {
              console.log('❌ Dirección no válida.');
            }
            setTimeout(holderManager, 1200);
          });
        });
        break;

      case '2':
        rl.question('\n#️⃣ Número a editar: ', (num) => {
          const idx = parseInt(num) - 1;
          if (idx >= 0 && idx < holders.length) {
            rl.question('✏️ Nuevo nombre: ', (newLabel) => {
              holders[idx].label = newLabel;
              saveHolders(holders);
              console.log('✅ Actualizado.');
              setTimeout(holderManager, 1200);
            });
          } else {
            console.log('❌ Número no válido.');
            setTimeout(holderManager, 1200);
          }
        });
        break;

      case '3':
        rl.question('\n#️⃣ Número a eliminar: ', (num) => {
          const idx = parseInt(num) - 1;
          if (idx >= 0 && idx < holders.length) {
            holders.splice(idx, 1);
            saveHolders(holders);
            console.log('✅ Eliminado.');
          } else {
            console.log('❌ Número no válido.');
          }
          setTimeout(holderManager, 1200);
        });
        break;

      default:
        mainMenu();
        break;
    }
  });
}

// ==========================================
// BUCLE DEL MENÚ PRINCIPAL
// ==========================================

function mainMenu() {
  console.clear();
  console.log('===========================================================');
  console.log('     🚀 SUITE MULTI-HERRAMIENTA SOLANA (MAINNET-BETA)');
  console.log('===========================================================');
  console.log('  1. 📊 BORISCAN-PRO (Analizador Avanzado Crypto)');
  console.log('  2. 💸 Enviar SOL (Mainnet-Beta)');
  console.log('  3. 🔍 Consultar saldo de cualquier dirección SOL');
  console.log('  4. 🔑 Ver claves públicas y privadas de wallet.json');
  console.log('  5. 📂 Cargar/Generar billetera local y ver saldo Mainnet');
  console.log('  6. 🏷️  Gestor y etiquetador de Holders (BRCN)');
  console.log('  7. ❌ Salir');
  console.log('===========================================================');

  rl.question('👉 Selecciona una opción (1-7): ', (option) => {
    switch (option.trim()) {
      case '1':
        runPythonAnalyzer();
        break;
      case '2':
        sendSolMainnet();
        break;
      case '3':
        checkAnyBalance();
        break;
      case '4':
        exportKeys();
        break;
      case '5':
        showLocalWallet();
        break;
      case '6':
        holderManager();
        break;
      case '7':
        console.log('\n👋 ¡Programa finalizado!');
        rl.close();
        process.exit(0);
        break;
      default:
        mainMenu();
        break;
    }
  });
}

// Iniciar aplicación
mainMenu();
