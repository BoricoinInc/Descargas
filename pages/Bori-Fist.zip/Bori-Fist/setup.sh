cat << 'EOF' > setup.sh
#!/bin/bash

echo "=========================================="
echo "🚀 INICIANDO INSTALACIÓN AUTOMÁTICA BRCN"
echo "=========================================="

# 1. Actualizar paquetes del sistema
if command -v pkg &> /dev/null; then
    echo "📦 Detectado Termux: Actualizando paquetes..."
    pkg update -y && pkg upgrade -y
    pkg install -y nodejs python git
elif command -v apt &> /dev/null; then
    echo "📦 Detectado Debian/Ubuntu: Actualizando paquetes..."
    sudo apt update -y && sudo apt upgrade -y
    sudo apt install -y nodejs npm python3 python3-pip git
fi

# 2. Instalación de dependencias de Node.js
echo ""
echo "⚡ Instalando paquetes de Node.js..."
if [ -f "package.json" ]; then
    npm install
else
    npm install @solana/web3.js
fi

# 3. Instalación de dependencias de Python
echo ""
echo "🐍 Instalando paquetes de Python..."
if [ -f "requirements.txt" ]; then
    pip install -r requirements.txt
else
    pip install requests urllib3 coinbase
fi

echo ""
echo "=========================================="
echo "✅ ¡INSTALACIÓN COMPLETA CON ÉXITO!"
echo "=========================================="
echo "Para iniciar la suite ejecuta:"
echo "  node index.js"
echo "=========================================="
EOF

chmod +x setup.sh
